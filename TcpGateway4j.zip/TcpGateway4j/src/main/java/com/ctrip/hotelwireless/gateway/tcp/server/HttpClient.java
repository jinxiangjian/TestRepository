package com.ctrip.hotelwireless.gateway.tcp.server;

import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * 
 * @author qit on 2016/3/18
 *
 */
public class HttpClient {
	private static final MediaType sotp = MediaType.parse("application/x-sotp; charset=utf-8");	
	private static OkHttpClient client = new OkHttpClient();
	
	public static byte[] post(String url, byte[] bytes) throws IOException {
		RequestBody body = RequestBody.create(sotp, bytes);
		Request request = new Request.Builder().url(url).post(body).build();
		Response response = client.newCall(request).execute();
		if(response.isSuccessful()) {
			return response.body().bytes();
		} else {
			throw new IOException("Unexpected code " + response);
		}
	}
}
