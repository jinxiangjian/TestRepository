package com.ctrip.hotelwireless.gateway.tcp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author qit on 2016/3/17
 *
 */
public class GatewayStart {
	protected static final Logger _logger = LoggerFactory.getLogger(GatewayStart.class);

	public static void main(String[] args) throws Exception {
		System.out.println("Starting the TCP server now.");
		GatewayContext gatewayContext = GatewayContext.getInstance();
		gatewayContext.getConfig().print();
		System.out.println("");
		gatewayContext.getServer().start();
		System.out.println("**************************************************************");
		System.out.println("****************** Tcp Server is listening *******************");
		System.out.println("**************************************************************");
		System.out.println("");
	}
}
