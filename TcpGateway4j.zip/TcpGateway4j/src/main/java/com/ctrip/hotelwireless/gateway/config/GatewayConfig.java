package com.ctrip.hotelwireless.gateway.config;

import java.util.HashMap;
import java.util.Map.Entry;

public class GatewayConfig {
	private static final String GATEWAYPORT_NM = "GatewayPort";
	private static final String RELAYPORT_NM = "RelayGatewayPort";
	private static final String RELAYIP_NM = "RelayGatewayIP";
	private static final String SERVICECODES_NM = "ServiceCodeList";
	
	public int gatewayPort;
	public int relayPort;
	public String relayIP;
	public HashMap<String, String> serviceCodeMap;
	
	public GatewayConfig() {
		gatewayPort = Integer.parseInt(Properties.envProperties.getString(GATEWAYPORT_NM, "8055"));
		relayPort = Integer.parseInt(Properties.envProperties.getString(RELAYPORT_NM, "443"));
		relayIP = Properties.envProperties.getString(RELAYIP_NM, "10.2.6.87");
		
		String[] serviceCodes = Properties.envProperties.getString(SERVICECODES_NM).split("/");
		serviceCodeMap = new HashMap<String, String>();
		for(String code : serviceCodes) {
			serviceCodeMap.put(code, Properties.envProperties.getString(code));
		}
	}
	
	public String getURLByServiceCode(String code) {
		return serviceCodeMap.get(code);
	}
	
	public static void main(String[] args) {
		new GatewayConfig();
    }
	
	public void print() {
		System.out.println("Port = " + gatewayPort);
		System.out.println("Relay_TCP_Server = " + relayIP + ":" + relayPort);
		System.out.println("Special Service Information:");
		for(Entry<String, String> entry : serviceCodeMap.entrySet()){
			System.out.println(entry.getKey() + " = " + entry.getValue());
		}
	}
}
