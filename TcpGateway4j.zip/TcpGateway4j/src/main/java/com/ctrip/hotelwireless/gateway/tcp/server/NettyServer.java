package com.ctrip.hotelwireless.gateway.tcp.server;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author qit on 2016/3/18
 *
 */
public class NettyServer implements NettyComponent{
	protected static final Logger _logger = LoggerFactory.getLogger(NettyServer.class);
	private int port;
	private ChannelFuture future;
	EventLoopGroup bossGroup = new NioEventLoopGroup();
	EventLoopGroup workerGroup = new NioEventLoopGroup();
	ServerBootstrap bootstrap = new ServerBootstrap(); 
    
    public NettyServer(int port) {
    	this.port = port;
    }
    
    private void bind() {
    	bootstrap.group(bossGroup, workerGroup)
    		.channel(NioServerSocketChannel.class)
    		.option(ChannelOption.SO_BACKLOG, 1024)
    		.option(ChannelOption.TCP_NODELAY, true)
    		.childOption(ChannelOption.SO_KEEPALIVE, true)
    		.childHandler(new ChannelInitializer<SocketChannel>() {
    			@Override
    			protected void initChannel(SocketChannel socketChannel) throws Exception {
    				socketChannel.pipeline().addLast(new TcpServerHandler());
    			}
    		});
    	
    	try{
    		future = bootstrap.bind(port).sync();
    		if(future.isSuccess()) {
    			_logger.info("Gateway server start successfully on port(" + port + ").");
    		}
    	} catch (InterruptedException e) {
    		_logger.info("Gateway server start failed, error message is: " + e.getMessage());
		}
    }
    
    public void start() {
    	bind();
    }
    
    public void stop() {
    	try {
    		future.channel().closeFuture().sync();
    		_logger.info("Gateway server stop successfully.");
    	} catch (InterruptedException e) {
    		_logger.info("catch exception when stop the gateway server, exception message is " + e.getMessage());
		} finally {
			bossGroup.shutdownGracefully();
			workerGroup.shutdownGracefully();
		}
    }
} 
