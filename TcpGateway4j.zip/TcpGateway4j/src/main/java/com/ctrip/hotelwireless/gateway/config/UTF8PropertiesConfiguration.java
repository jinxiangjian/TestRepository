package com.ctrip.hotelwireless.gateway.config;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;

/**
 * Created by lilinjun on 2016/2/29.
 */
public class UTF8PropertiesConfiguration extends PropertiesConfiguration {
    public UTF8PropertiesConfiguration(String propertiesFileName) {
        super();
        this.setEncoding("UTF-8");
        try {
            this.load(propertiesFileName);
        } catch (ConfigurationException e) {
            e.printStackTrace();
        }

    }
}
