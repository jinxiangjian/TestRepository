package com.ctrip.hotelwireless.gateway.tcp.server;

public interface NettyComponent {
	
	void start();
	
	void stop();
}
