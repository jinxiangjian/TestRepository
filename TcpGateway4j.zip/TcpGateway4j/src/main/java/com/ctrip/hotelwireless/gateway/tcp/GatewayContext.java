package com.ctrip.hotelwireless.gateway.tcp;

import io.netty.channel.socket.SocketChannel;

import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import com.ctrip.hotelwireless.gateway.config.GatewayConfig;
import com.ctrip.hotelwireless.gateway.tcp.server.NettyServer;

/**
 * 
 * @author qit on 2016/3/18
 *
 */
public class GatewayContext {
	private static GatewayContext instance;
	private NettyServer server;
	private GatewayConfig config;
	private ConcurrentHashMap<SocketChannel, SocketChannel> channelPair;
	
	private GatewayContext() { 
		channelPair = new ConcurrentHashMap<SocketChannel, SocketChannel>();    //key=clientChannel, value=serverChannel
		config = new GatewayConfig();
		server = new NettyServer(config.gatewayPort);
	}
	
	public static GatewayContext getInstance() {
		if(instance == null) {
			instance = new GatewayContext();
		}
		return instance;
	}
	
	public String getURLByServiceCode(String code) {
		return config.getURLByServiceCode(code);
	}
	
	public NettyServer getServer() {
		return server;
	}
	
	public void setServer(NettyServer server) {
		this.server = server;
	}

	public GatewayConfig getConfig() {
		return config;
	}
	
    public void putChannelPair(SocketChannel clientChannel, SocketChannel serverChannel) {
    	channelPair.putIfAbsent(clientChannel, serverChannel);
    }
    
    public SocketChannel getServerChannel(SocketChannel clientChannel) {
    	return channelPair.get(clientChannel);
    }
    
    public SocketChannel removeChannelByServer(SocketChannel serverChannel) {
    	for(Entry<SocketChannel, SocketChannel> entry : channelPair.entrySet()) {
    		if(entry.getValue() == serverChannel) {
    			channelPair.remove(entry.getKey());
    			return entry.getKey();
    		}
    	}
    	return null;
    }
    
    public void removeChannelByClient(SocketChannel clientChannel) {
    	channelPair.remove(clientChannel);
    }
	
}
