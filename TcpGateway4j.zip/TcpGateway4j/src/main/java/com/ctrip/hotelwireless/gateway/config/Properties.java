package com.ctrip.hotelwireless.gateway.config;

import java.util.Iterator;

import org.apache.commons.configuration.PropertiesConfiguration;

import com.ctrip.hotelwireless.gateway.tcp.util.ProjectPathUtil;


public class Properties {
    public static PropertiesConfiguration envProperties;
    public static final String DEFAULT_CONFIG_FILE = ProjectPathUtil.getProjectPath() + "config/gateway.properties";
    static{
        envProperties = new UTF8PropertiesConfiguration(DEFAULT_CONFIG_FILE);
    }
    
    public static void main(String[] args) {
    	Iterator<String> keys = Properties.envProperties.getKeys();
    	while(keys.hasNext()) {
    		String key = keys.next();
    		System.out.println(Properties.envProperties.getString(key));
    	}
    }
}
