package com.ctrip.hotelwireless.gateway.tcp.server;

import java.io.IOException;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ctrip.hotelwireless.gateway.tcp.GatewayContext;
import com.ctrip.hotelwireless.gateway.tcp.util.BinaryUtil;
import com.ctrip.mobile.common.SerializeUtil;
import com.ctrip.mobile.common.model.Request;
import com.google.gson.Gson;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerAdapter;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.socket.SocketChannel;

/**
 * 
 * @author qit on 2016/3/17
 *
 */
public class TcpServerHandler extends ChannelHandlerAdapter {
	protected static final Logger _logger = LoggerFactory.getLogger(TcpServerHandler.class);
	private SocketChannel channel;
	
	@Override
	public void channelActive(ChannelHandlerContext ctx) throws Exception {
		_logger.debug("Gateway accept the app connection request [app->server].");
		GatewayContext gatewayContext = GatewayContext.getInstance();
		NettyClient client = new NettyClient(gatewayContext.getConfig().relayPort, gatewayContext.getConfig().relayIP);
		client.start();
		channel = client.getChannel();
		if(channel != null) {
			GatewayContext.getInstance().putChannelPair(channel, (SocketChannel)ctx.channel());
		}
	}

	@Override
	public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
		ByteBuf buf = (ByteBuf) msg;
		buf.markReaderIndex();
		byte[] bytes = new byte[buf.readableBytes()];
		buf.readBytes(bytes);
		buf.resetReaderIndex();
		_logger.info("Gateway receive package [app->server]:" + BinaryUtil.BinaryToHexString(bytes));
		
		Request deCodeRequest = SerializeUtil.deCodeRequest(bytes);
		
		String serviceURL = GatewayContext.getInstance().getURLByServiceCode(deCodeRequest.getHead().getServiceCode());
		if(StringUtils.isNotBlank(serviceURL)) {
			_logger.info("Gateway forward package [server->soa]:" + BinaryUtil.BinaryToHexString(bytes));
			try{
				byte[] response = HttpClient.post(serviceURL, bytes);
				_logger.info("Gateway receive package [soa->server]:" + BinaryUtil.BinaryToHexString(response));
				/*
				Response deCodeResponse = SerializeUtil.deCodeResponse(response);
				System.out.println("clientResponse:" + new Gson().toJson(deCodeResponse));
				try {
					Method newBuilder = HotelCommentUsefulSubmitResponse.class.getMethod("newBuilder");
					GeneratedMessage.Builder builder = (GeneratedMessage.Builder) newBuilder.invoke(HotelCommentUsefulSubmitResponse.class);
					byte[] xx = deCodeResponse.getBody();
			        Message message = builder.mergeFrom(xx).build();
			        System.out.println("clientResponse Body:" + new Gson().toJson(message));
			        if(message instanceof HotelCommentUsefulSubmitProto.HotelCommentUsefulSubmitResponse) {
			        	HotelCommentUsefulSubmitProto.HotelCommentUsefulSubmitResponse msg1 = (HotelCommentUsefulSubmitProto.HotelCommentUsefulSubmitResponse)message;
			        	System.out.println("respone body content: " + msg1.getResultCode());
			        	System.out.println("respone body content: " + msg1.getResultMessage());
			        }
				} catch (Exception e){
					e.printStackTrace();
				}
				*/
				ByteBuf resp = Unpooled.copiedBuffer(response);
				ctx.writeAndFlush(resp);
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}else{
			_logger.info("Gateway forward package [server->relay]:" + BinaryUtil.BinaryToHexString(bytes));
			channel.writeAndFlush(buf);
		}
	}

	@Override
	public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
		ctx.flush();
	}

	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
		cause.printStackTrace();
		ctx.close();
	}
	
	@Override
	public void channelInactive(ChannelHandlerContext ctx) throws Exception {
		_logger.info("channel between app and gateway closed.");
		SocketChannel clientChannel = GatewayContext.getInstance().removeChannelByServer((SocketChannel) ctx.channel());
		if(clientChannel != null && clientChannel.isActive()){
			clientChannel.disconnect();
		}	
	}
	
}
