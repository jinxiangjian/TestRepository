package com.ctrip.hotelwireless.gateway.tcp.server;

import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author qit on 2016/3/18
 *
 */
public class NettyClient implements NettyComponent{
	protected static final Logger _logger = LoggerFactory.getLogger(NettyClient.class);
    private int port;
    private String host;
    private SocketChannel socketChannel;
    private ChannelFuture future;
    private EventLoopGroup eventLoopGroup=new NioEventLoopGroup();
    private Bootstrap bootstrap=new Bootstrap();

    public NettyClient(int port, String host) {
        this.port = port;
        this.host = host;
    }
    
    private void connect() {
    	bootstrap.channel(NioSocketChannel.class);
        bootstrap.option(ChannelOption.SO_KEEPALIVE,true);
        bootstrap.group(eventLoopGroup);
        bootstrap.remoteAddress(host,port);
        bootstrap.handler(new ChannelInitializer<SocketChannel>() {
            @Override
            protected void initChannel(SocketChannel socketChannel) throws Exception {
                socketChannel.pipeline().addLast(new TcpClientHandler());
            }
        });
        
        try {
			future = bootstrap.connect(host,port).sync();
			if (future.isSuccess()) {
	            socketChannel = (SocketChannel)future.channel();
	            _logger.info("Gateway connect relay tcp server successfully.");
	        }
		} catch (InterruptedException e) {
			_logger.info("Gateway connect relay tcp server failed, error message is:" + e.getMessage());
		} 
    }
    
    @Override
    public void start() {
    	connect();
    }
    
    @Override
	public void stop() {
    	try {
    		future.channel().closeFuture().sync();
    	} catch (InterruptedException e) {
    		_logger.info("catch exception when gateway disconnect relay tcp server, exception message is " + e.getMessage());
		} finally {
			eventLoopGroup.shutdownGracefully();
		}
	}
        
    public void reconnect() { 
    	try {
			future = bootstrap.connect(host,port).sync();
			if (future.isSuccess()) {
	            socketChannel = (SocketChannel)future.channel();
	            _logger.info("Gateway connect relay tcp server successfully.");
	        }
		} catch (InterruptedException e) {
			_logger.info("Gateway connect relay tcp server failed, error message is:" + e.getMessage());
		} 
    }
    
    public void write(ByteBuf firstMessage) {
    	if(socketChannel == null && !socketChannel.isActive()){
    		_logger.debug("socket channel between gateway and relay tcp server is closed, and will reconnect it now.");
    		reconnect();
    	}
    	socketChannel.writeAndFlush(firstMessage);
    }
    
    public SocketChannel getChannel() {
    	return socketChannel;
    }

}
